library(testthat)
library(lofr)

test_check("lofr")
